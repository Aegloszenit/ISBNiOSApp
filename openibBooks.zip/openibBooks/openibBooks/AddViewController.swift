//
//  AddViewController.swift
//  openibBooks
//
//  Created by Alejandro Martinez Montero on 12/5/18.
//  Copyright © 2018 Alejandro Martinez Montero. All rights reserved.
//

import UIKit
import SystemConfiguration
import CoreData

class AddViewController: UIViewController {

    @IBOutlet weak var textToSearch: UITextField!
    @IBOutlet weak var imageToShow: UIImageView!
    @IBOutlet weak var titleOfSearch: UILabel!
    @IBOutlet weak var authorOfSearch: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */
    func isInternetAvailable() -> Bool
    {
        var zeroAddress = sockaddr_in()
        zeroAddress.sin_len = UInt8(MemoryLayout.size(ofValue: zeroAddress))
        zeroAddress.sin_family = sa_family_t(AF_INET)
        
        let defaultRouteReachability = withUnsafePointer(to: &zeroAddress) {
            $0.withMemoryRebound(to: sockaddr.self, capacity: 1) {zeroSockAddress in
                SCNetworkReachabilityCreateWithAddress(nil, zeroSockAddress)
            }
        }
        
        var flags = SCNetworkReachabilityFlags()
        if !SCNetworkReachabilityGetFlags(defaultRouteReachability!, &flags) {
            return false
        }
        let isReachable = flags.contains(.reachable)
        let needsConnection = flags.contains(.connectionRequired)
        return (isReachable && !needsConnection)
    }
    func specificData(rawTextToConvert: Data)  {
        let myJson = try? JSONSerialization.jsonObject(with: rawTextToConvert, options: JSONSerialization.ReadingOptions.mutableLeaves)
        
        let myDictionary = myJson as! NSDictionary
        let myStringtitle = "ISBN:" + textToSearch.text!

        if let xx = myDictionary[myStringtitle] as? NSDictionary {
            print("eureka")
            let myInsertedDict = myDictionary[myStringtitle] as! NSDictionary
            let bookTitle = myInsertedDict["title"] as! NSString
            titleOfSearch.text = bookTitle as String
            print(myDictionary[myStringtitle]  ?? "nothing to see")
            let coverHttpPage = URL(string: "http://covers.openlibrary.org/b/ISBN/" + textToSearch.text! + "-M.jpg")
            let theAuthors = myInsertedDict["authors"] as! NSArray
            print(theAuthors.count)
            
            var authorsTextNames = ""
            for authorItem in theAuthors {
                let objectItem = authorItem as! NSDictionary
                authorsTextNames += (objectItem["name"] as! NSString) as String
                authorsTextNames += ", "
            }
            authorOfSearch.text = authorsTextNames
            imageToShow.isHidden = false
            if let myImageBook = try? Data(contentsOf: coverHttpPage!) {
                imageToShow.image = UIImage(data: myImageBook)
            }
            let appDelegate = UIApplication.shared.delegate as! AppDelegate
            let context = appDelegate.persistentContainer.viewContext
            let entity = NSEntityDescription.entity(forEntityName: "BooksLists", in: context)
            let newUser = NSManagedObject(entity: entity!, insertInto: context)
            newUser.setValue(bookTitle as String, forKey: "title")
            
            let isbnentity = NSEntityDescription.entity(forEntityName: "Isbn", in: context)
            let newIsbn = NSManagedObject(entity: isbnentity!, insertInto: context)
            let searchString = textToSearch.text!
            newIsbn.setValue(searchString, forKey: "title")
            

            
            do {
                try context.save()
            }
            catch {
                print("no save possible")
            }
            //http://covers.openlibrary.org/b/$key/$value-$size.jpg
            //key can be any one of ISBN, OCLC, LCCN, OLID and ID (case-insensitive)
            //value is the value of the chosen key
            //size can be one of S, M and L for small, medium and large respectively.
        }
        else {
            titleOfSearch.text = "no title"
            authorOfSearch.text = "no author"
        }
        

        
    }
    
    
    func sincrono() {
        let urls = "https://openlibrary.org/api/books?jscmd=data&format=json&bibkeys=ISBN:" + textToSearch.text!
        let url = NSURL(string: urls)
        let datos:NSData? = NSData(contentsOf: url! as URL)
        specificData(rawTextToConvert: datos! as Data)
        let texto = NSString(data: datos! as Data, encoding: String.Encoding.utf8.rawValue)
        //print(texto!)
        //textViewElement.text = texto! as String
    }

    @IBAction func searchBookISBN(_ sender: Any) {
        let xx = isInternetAvailable()
        if xx == true {
            sincrono()
        }
        else {
            titleOfSearch.text = "no internet connection"
            authorOfSearch.text = "no internet connection"
            //textViewElement.text = "There is no internet or the site is not correct"
        }
    }
}
